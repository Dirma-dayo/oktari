export const showcase = [
  { 
    name: "calritybase", 
    img: "/clariti.png", 
    href: "https://www.claritybase.icu",
    description: "Web untuk showcase website kamu!" 
  },
  { 
    name: "Jurnal Kelas", 
    img: "/jurnal.png", 
    href: "https://jurnal-kelas.vercel.app/dashboard",
    description: "Jurnaling untuk kelas." 
  },
  { 
    name: "uang kas thing", 
    img: "/showcase3.png", 
    href: "#",
    description: "Web untuk melihat uang kas kelas." 
  },
];
