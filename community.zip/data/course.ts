export const course = [
  { 
    name: "kurssus a", 
    img: "/gmba1.png", 
    href: "",
    description: "blabla" 
  },
  { 
    name: "kurssus b", 
    img: "/gmba2.png", 
    href: "",
    description: "blabla" 
  },
  { 
    name: "kurssus c", 
    img: "/gmba3.png", 
    href: "",
    description: "blabla" 
  },
  { 
    name: "kurssus cd", 
    img: "/gmba3.png", 
    href: "",
    description: "blabla" 
  },
  { 
    name: "kurssus c", 
    img: "/gmba3.png", 
    href: "",
    description: "blabla" 
  },
  { 
    name: "kurssus c", 
    img: "/gmba3.png", 
    href: "",
    description: "blabla" 
  },
];
